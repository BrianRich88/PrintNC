# Setup a Development Environment

```
cd $HOME
git clone git@github.com:linuxcnc-probe-screen/probe-screen-ng.git
cd $HOME/linuxccnc/configs/MyConfigName
ln -s $HOME/probe-screen-ng/psng psng
ln -s $HOME/probe-screen-ng/python python
```

To change branch: `git checkout files_cleanup`
